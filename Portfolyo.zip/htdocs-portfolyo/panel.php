<?php
ini_set("display_errors", 1);
ini_set("display_startup_errors", 1);
error_reporting(E_ALL);
session_start();

require_once("layout/header.php");

require_once("config.php");

// Giriş yapıp yapmadığımı kontrol eder.
if (!isset($_SESSION["username"])) {
    header("Location: login.php");
    exit();
}

// Kullanıcıları listeleme veri tabanından verileri çektiğim kısım
$query = "SELECT * FROM icerikler WHERE kayitDurumu=1";
$stmt = $conn->query($query);
$icerikler = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Yeni kullanıcı ekleme
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["icerikEkle"])) {
    $contentName = $_POST["icerikAdi"];
    $content = $_POST["icerik"];


    //İçerik Ekleme kısmı
    $insertQuery = "INSERT INTO icerikler (icerikAdi, icerik) VALUES (:icerikAdi, :icerik)";
    $insertStmt = $conn->prepare($insertQuery);
    $insertStmt->bindParam(':icerikAdi', $contentName);
    $insertStmt->bindParam(':icerik', $content);
    $insertStmt->execute();

    header("Location: panel.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["icerikGuncelle"])) {

    $id = $_POST["id"];
    $contentName = $_POST["icerikAdi"];
    $content = $_POST["icerik"];

    //İçerik Silme Düzenleme kısmı
    $Query = "UPDATE icerikler SET icerikAdi =:icerikAdi,icerik = :icerik WHERE id=:id";
    $insertStmt = $conn->prepare($Query);
    $insertStmt->bindParam(':icerikAdi', $contentName);
    $insertStmt->bindParam(':icerik', $content);
    $insertStmt->bindParam(':id', $id);
    $insertStmt->execute();

    header('Location:panel.php');
    exit();
}
?>


<h2>Panel</h2>
<p>Hoş geldiniz,
    <?php echo $_SESSION["username"]; ?>! [<a href="logout.php">Çıkış yap</a>]
</p>
<div class="d-flex justify-content-between">
    <h3>İcerikler</h3>
    <button type="button" data-bs-toggle="modal" data-bs-target="#staticBackdrop">İçerik Ekleme</button>
</div>

<table class="table">
    <thead>
        <tr>
            <th scope="col">id</th>
            <th scope="col">İcerik_Adi</th>
            <th scope="col">İcerikler</th>
            <th scope="col">DosyaAdı</th>
            <th scope="col">İşlemler</th>
        </tr>
    </thead>
    <tbody>
        <!-- -->
        <?php foreach ($icerikler as $content): ?>

            <tr>
                <th scope="row">
                    <?php echo $content["id"]; ?>
                </th>
                <td>
                    <?php echo $content["icerikAdi"]; ?>
                </td>
                <td>
                    <?php echo $content["icerik"]; ?>
                </td>
                <td>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop"
                        onclick="IcerikBilgiGetir(<?php echo $content['id']; ?>)">Düzenle</button>
                    <button class="btn btn-danger" onclick="Sil(<?php echo $content['id']; ?>)">Sil</button>
                </td>
            </tr>

        <?php endforeach; ?>


    </tbody>
</table>

<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">Güncelle</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <div class="modal-body">
                <form method="post" action="" class="" id="veriform">
                    <input type="hidden" id="id" name="id" style="border-radius:10px; margin-top:10px;">
                    <label for="icerikAdi">İcerik Adi:</label>
                    <input type="text" id="icerikAdi" name="icerikAdi" class="w-100 mb-2"
                        style="border-radius: 10px; padding:5px;"><br>
                    <label for="dosyaId">Dosya:</label>
                    <select id="dosyaId" name="dosyaId" class="w-100 mb-2"
                        style="border-radius: 10px; width:100%; padding:5px;">

                    </select><br>
                    <label for="icerikAdi">İçerik:</label>
                    <textarea name="icerik" id="icerik" cols="55" rows="0" style></textarea>

                    <!-- <input type="submit" value="Ekle" style="border-radius: 10px;"> -->
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button>
                <button type="submit" class="btn btn-primary" name="icerikGuncelle" form="veriform">Güncelle</button>
                <button type="submit" class="btn btn-primary" name="icerikEkle" form="veriform">Ekle</button>
            </div>
        </div>
    </div>
</div>

<h2>File Upload Form</h2>
<form action="api.php" method="post" enctype="multipart/form-data">
    <label for="file">Dosya Seç:</label>
    <input type="file" name="file" id="file" required>
    <input type="hidden" name="operation" value="Upload">
    <br>
    <input type="submit" name="submit" value="Yükle">
</form>

<script>
    function IcerikBilgiGetir(id) {
        $.ajax({
            "url": `/api.php`,
            "method": "GET",
            "dataType": "JSON",
            "data": {
                "id": id,
                "operation": "IcerikBilgiGetir"
            },
            "success": res => {
                console.log("res", res);
                for (const key in res) $(`#staticBackdrop [name='${key}']`).val(res[key]);

                // document.getElementById("icerikAdi").value = res.icerikAdi;
                // document.getElementById("icerik").value = res.icerik;
                // document.getElementById("id").value = res.id;
            },
            "error": e => alert("İşlem sırasında bir hata oluştu"),
            "beforeSend": e => $("#loader").show(),
            "complete": e => $("#loader").hide(),
        });
    }



    function Sil(id) {
        if (!confirm("Silmek istediğinize emin misiniz?")) return;
        $.ajax({
            "url": `/api.php`,
            "method": "POST",
            "dataType": "JSON",
            "data": {
                "id": id,
                "operation": "sil"
            },
            "success": res => {
                window.location = "";
            },
            "error": e => alert("İşlem sırasında bir hata oluştu"),
            "beforeSend": e => $("#loader").show(),
            "complete": e => $("#loader").hide(),
        });
    }

    function formatState(state) {
        const baseUrl = `/upload/${state.img}`;
        return $(`<img src="${baseUrl}" style="height: 60px;"/>`);
    };

    $("#dosyaId").select2({
        "ajax": {
            url: "./api.php",
            method: "GET",
            dataType: "JSON",
            data: {
                operation: "fileList"
            },
            "processResults": res => {
                
                return {
                    "results": res.data.map(d => ({
                        "id": d.id,
                        "text": d.filePath,
                        "img": d.filePath
                    }))
                }
            }
        },
        dropdownParent: $('#staticBackdrop'),
        templateSelection: formatState,
        templateResult: formatState,
    });
</script>


<?php
include_once("layout/footer.php")
    ?>