<?php 
include_once("layout/header.php"); 
include_once("layout/navbar.php"); 
?>

<div id="carouselExampleFade" class="customSlide carousel slide carousel-fade">
  <div class="carousel-inner">
    <div class="carousel-item active">
    <img src="/images/web-tasarim.jpeg"  class="custom-slide-item" alt="">
    </div>
    <div class="carousel-item">
      <img src="/images/siber.jpg" class="custom-slide-item" alt="">
    </div>
    <div class="carousel-item">
      <img src="/images/programlama.jpg" class="custom-slide-item" alt="">
    </div>
    <!-- <div class="carousel-item">
      <div class="custom-slide-item" style="background-image:url(/images/siber.jpg)"></div>
    </div>
    <div class="carousel-item">
      <div class="custom-slide-item" style="background-image:url(/images/programlama.jpg)"></div>
    </div> -->
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev" style="position: absolute;">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next" style="position: absolute;">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>


<?php include_once("if.php"); ?>

<?php include_once("layout/footer.php"); ?>