<div class="container" style="position: relative; bottom:0; left:0; right:0;">
  <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
    <p class="col-md-4 mb-0 text-muted">© 2023 Company, Inc</p>
   <div class="socialmedia-icon">
    <a href="https://www.instagram.com/serhataydilek23/">
    <img src="/social-media-icon/instagram.png" alt="">
    </a>

    <a href="https://github.com/serhata23">
    <img src="/social-media-icon/github.png" alt="">
    </a>
    <a href="https://www.linkedin.com/in/serhat-aydilek-5a512123b/">
    <img src="/social-media-icon/linkedin.png" alt="">
    </a>
   </div>
    <ul class="nav col-md-4 justify-content-end">
      <li class="nav-item"><a href="/index.php" class="nav-link px-2 text-muted">Anasayfa</a></li>
      <li class="nav-item"><a href="/portfolyo.php" class="nav-link px-2 text-muted">Portfolyo</a></li>
      <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Hakkımda</a></li>
    </ul>
  </footer>
</div>


<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script src="../js/main.js"></script>
<script>
  $(document).ready(() => {
    setTimeout(() => {
      $(".loader-content").fadeOut();
    }, 700);
    
  });
</script>
</body>

</html>