<?php

session_start();
$URL = $_SERVER["REQUEST_URI"];
?>
<nav class="navbar bg-body-tertiary fixed-top">
  <div class="container-fluid">
    <a href="/index.php"> 
      <img src="./images/logo.png" alt="" class="logo" style="max-width: 100px;">
    </a>





    <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar"
      aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
      <i class="fa-solid fa-bars"></i>
    </button>
    <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
      <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="offcanvasNavbarLabel"><a href="/index.php"><img src="./images/logo.png"
              style="max-width: 100px;" alt=""></a></h5>

        <label style="margin-top: 15px;">
          <input class="slider" type="checkbox" id="changeThemeBtn">
          <div class="switch">
            <div class="suns"></div>
            <div class="moons">
              <div class="star star-1"></div>
              <div class="star star-2"></div>
              <div class="star star-3"></div>
              <div class="star star-4"></div>
              <div class="star star-5"></div>
              <div class="first-moon"></div>
            </div>
            <div class="sand"></div>
            <div class="bb8">
              <div class="antennas">
                <div class="antenna short"></div>
                <div class="antenna long"></div>
              </div>
              <div class="head">
                <div class="stripe one"></div>
                <div class="stripe two"></div>
                <div class="eyes">
                  <div class="eye one"></div>
                  <div class="eye two"></div>
                </div>
                <div class="stripe detail">
                  <div class="detail zero"></div>
                  <div class="detail zero"></div>
                  <div class="detail one"></div>
                  <div class="detail two"></div>
                  <div class="detail three"></div>
                  <div class="detail four"></div>
                  <div class="detail five"></div>
                  <div class="detail five"></div>
                </div>
                <div class="stripe three"></div>
              </div>
              <div class="ball">
                <div class="lines one"></div>
                <div class="lines two"></div>
                <div class="ring one"></div>
                <div class="ring two"></div>
                <div class="ring three"></div>
              </div>
              <div class="shadow"></div>
            </div>
          </div>
        </label>

        <button type="button" class="btn btn-link" data-bs-dismiss="offcanvas" aria-label="Close">
          <i class="fa-solid fa-xmark btn-close"></i>
        </button>
      </div>
      <div class="offcanvas-body">
        <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
          <li class="nav-item">
            <a class="nav-link <?= $URL == "/index.php" ? "active" : "" ?>" aria-current="page"
              href="/index.php">ANASAYFA</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?= $URL == "/portfolyo.php" ? "active" : "" ?>" href="/portfolyo.php">PORTFOLYO</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?= $URL == "/hakkimda.php" ? "active" : "" ?>" href="/hakkimda.php">HAKKIMDA</a>
          </li>


          <?php if (isset($_SESSION["user"])) { ?>

          <li class="nav-item">
            <a class="nav-link <?= $URL == "/profilim.php" ? "active" : "" ?>" href="/profilim.php">PROFİLİM</a>
          </li>

            <li class="nav-item">
              <a class="nav-link" href="api.php?operation=logout">ÇIKIŞ YAP</a>
            </li>
          <?php } else { ?>
            <li class="nav-item">
              <a class="nav-link <?= $URL == "/userlogin.php" ? "active" : "" ?>" href="/userlogin.php">GİRİŞ YAP</a>
            </li>
          <?php } ?>

          <script>
            
          </script>


          <form class="d-flex mt-3" role="search">
            <input class="form-control me-2" type="search" placeholder="ARA " aria-label="Search">
            <button class="btn btn-outline-success" type="submit">ARA</button>
          </form>
      </div>
    </div>
  </div>
</nav>