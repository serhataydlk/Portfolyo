<?php
ini_set("display_errors",1);
ini_set("display_startup_errors",1);
error_reporting(E_ALL);
session_start();
include_once("layout/header.php");
include_once("navbar.php");

require_once("config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $sql = "SELECT * FROM kisiler WHERE email = :email AND sifre = :sifre";
    $result = $conn->prepare($sql);
    $kontrol = $result->execute(["email" => $username, "sifre" => $password]);
    $result = $result->fetch(PDO::FETCH_ASSOC);


    if (!empty($result)) {
        // Kullanıcı doğrulandı
        $_SESSION["username"] = $username;
        header("Location: panel.php"); // Giriş başarılıysa yönlendirilecek sayfa
        exit;
    } else {
        $error = "Geçersiz kullanıcı adı veya şifre";
    }
}

?>
<div style="margin-top: 185px;">
    <h2>Login</h2>
    <form method="post" action="/login.php" > 
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Email address</label>
            <input type="text" class="form-control" name="username" id="exampleInputEmail1" aria-describedby="emailHelp">
            <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
        </div>
        <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">Password</label>
            <input type="password" name="password"  class="form-control" id="exampleInputPassword1">
        </div>
        <div class="mb-3 form-check">
            <input type="checkbox" class="form-check-input" id="exampleCheck1">
            <label class="form-check-label" for="exampleCheck1">Check me out</label>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>




<?php if (isset($error)) {
    echo "<p>$error</p>";
} ?>

<?php include_once("layout/footer.php"); ?>
