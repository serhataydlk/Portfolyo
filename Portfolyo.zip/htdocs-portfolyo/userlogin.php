<?php
session_start();
include_once 'config.php'; // Veritabanı bağlantısı dosyanızın doğru yolunu belirtmelisiniz

if (isset($_SESSION['user']) != "") {
    header("Location: index.php");
    exit;
}

$error = false;

if (isset($_POST['btn-login'])) {

    $userEmail = trim($_POST['email']);
    $userPass = trim($_POST['password']);

    if (empty($userEmail)) {
        $error = true;
        $emailError = "Please enter your email address.";
    } else if (!filter_var($userEmail, FILTER_VALIDATE_EMAIL)) {
        $error = true;
        $emailError = "Please enter a valid email address.";
    }

    if (empty($userPass)) {
        $error = true;
        $passError = "Please enter your password.";
    }

    if (!$error) {

        //$userPass = password_hash($userPass, PASSWORD_DEFAULT );

        $query = "SELECT userId, userName, userPass FROM users WHERE userEmail=:email";
        $stmt = $conn->prepare($query);
        $stmt->bindValue(":email", $userEmail);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $count = $stmt->rowCount();



        if ($count == 1 && password_verify($userPass, $row['userPass'])) {
            $_SESSION['user'] = $row['userId'];
            header("Location: index.php");
            exit;
        } else {
            $errMSG = "Kullanıcı adı ve şifreniz hatalıdır.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/css/userlogin.css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.1/dist/sweetalert2.all.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.1/dist/sweetalert2.min.css" rel="stylesheet">
</head>

<body style="overflow: hidden;">

    <div style="display: flex; justify-content: center; height: 100vh; align-items: center;">

        <div class="container">
            <div class="heading" id="myheading">Giriş Yap</div>
            <form id="girisYapForm" method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>"
                class="form">
                <input required="" class="input" type="email" name="email" id="email" placeholder="E-mail">
                <input required="" class="input" type="password" name="password" id="password" placeholder="Password">
                <span class="forgot-password"><a href="#">Forgot Password ?</a></span>
                <button class="login-button" type="submit" name="btn-login" style="margin-left: -0px;">Giriş
                    Yap</button>

                <button class="login-button" name="btn-singup" style="margin-right:10px;"
                    onclick="Degistir(event)">Kayıt Ol</button>
            </form>


            <form id="kayitOlForm" method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>"
                class="form" style="display:none;">
                <input required="" class="input" type="text" name="name" id="name" placeholder="Name">
                <input required="" class="input" type="email" name="email" id="email" placeholder="E-mail">
                <input required="" class="input" type="password" name="password" id="password" placeholder="Password">
                <span class="forgot-password"><a href="#">Forgot Password ?</a></span>
                <button class="login-button" type="submit" name="btn-login" style="margin-left: -0px;">Giriş
                    Yap</button>
                <button class="login-button" name="btn-singup" style="margin-right:10px;" onclick="KayitOl(event)">Kayıt
                    Ol</button>
            </form>


</body>

<script>

    function Degistir(e) {
        e.preventDefault();
        console.log($("#girisYapForm"));;
        console.log($("#kayitOlForm"));;
        $("#kayitOlForm").show();
        document.getElementById("myheading").textContent = "Kayıt Ol";
        $("#girisYapForm").hide();
        console.log("Buton çalışıyor");
    }

    function KayitOl(e) {
        e.preventDefault();
        const data = $('#kayitOlForm').serializeArray();
        data.push({
            "name": "operation",
            "value": "kayitOl",
        });
        $.ajax({
            'url': 'api.php',
            'method': 'POST',
            "dataType": "JSON",
            'data': data,
            "success": res => {
                if (res.valid) {
                    alert("İşlem başarılı...");
                    location.href = "/userlogin.php";
                } else {
                    (Array.isArray(res?.err) ? res.err : []).forEach(e => alert(e));
                }
            },
            "error": e => alert("İşlem sırasında bir hata oluştu!")
            // 'data': {
            //     'name': $('#userName').val(),
            //     'email': $('#email').val(),
            //     'password': $('#password').val(),
            // }
        });

    }



</script>



<?php if (isset($errMSG)) { ?>
    <script>
        $(document).ready(function () {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: '<?= $errMSG ?>',
            });
        })
    </script>
    <?php unset($errMSG);
} ?>

</html>