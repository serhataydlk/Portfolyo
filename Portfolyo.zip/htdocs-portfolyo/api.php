<?php

ini_set("display_errors", 1);
ini_set("display_startup_errors", 1);
error_reporting(E_ALL);

session_start();
require_once("config.php");

function OperationCheck($operation)
{
    return isset($_REQUEST["operation"]) && $_REQUEST["operation"] == $operation;
}
function PrintJsonVal($val)
{
    echo json_encode($val);
}


if (OperationCheck("logout")) {


    // Kullanıcı oturumu varsa, oturumu kapat ve index.php'ye yönlendir
    if (isset($_SESSION['user'])) {
        unset($_SESSION['user']);
        session_destroy();
    }

    header("Location:userlogin.php");
    exit;
}

if (OperationCheck("kayitOl")) {
    $result = ["valid" => true, "err" => []];

    $userName = trim($_POST['name']);
    $userName = strip_tags($userName);
    $userName = htmlspecialchars($userName);

    $userEmail = trim($_POST['email']);
    $useremail = strip_tags($userEmail);
    $userEmail = htmlspecialchars($userEmail);

    $pass = trim($_POST['password']);
    $pass = strip_tags($pass);
    $pass = htmlspecialchars($pass);

    if (empty($userName)) {
        $result['valid'] = false;
        $result["err"][] = "Please enter your full name.";
    }

    if (empty($userEmail)) {
        $result['valid'] = false;
        $result["err"][] = "Please enter your email address.";
    } elseif (!filter_var($userEmail, FILTER_VALIDATE_EMAIL)) {
        $result['valid'] = false;
        $result["err"][] = "Please enter a valid email address.";
    } else {
        $sql = "SELECT userEmail FROM users WHERE userEmail=:email limit 1";
        $resultSql = $conn->prepare($sql);
        $kontrol   = $resultSql->execute(["email" => $userEmail]);
        $resultSql = $resultSql->fetchAll(PDO::FETCH_ASSOC);

        if (!empty($resultSql)) {
            $result['valid'] = false;
            $result["err"][] = "Provided email is already in use.";
        }
    }

    if (empty($pass)) {
        $result['valid'] = false;
        $result["err"][] = "Lütfen şifrenizi giriniz.";

    } elseif (strlen($pass) < 6) {
        $result['valid'] = false;
        $result["err"][] = "Şifre uzunluğunuz en az 6 karakter olmalıdır.";
    }

    if ($result["valid"]) {
        $userPass = password_hash($pass, PASSWORD_DEFAULT);

        $query = "INSERT INTO users(userName, userEmail, userPass) VALUES(:userName, :email, :userPass)";
        $resultSql = $conn->prepare($query);
        $res = $resultSql->execute(["email" => $userEmail, "userPass" => $userPass, "userName" => $userName]);
        if ($res) {
            // $_SESSION['user'] = $conn->lastInsertId();
        } else {
            $result['valid'] = false;
            $result["err"][] = "Bir şeyler ters gitti daha sonra tekrar deneyiniz";
        }
    }
    PrintJsonVal($result);
    exit;
}


if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit();
}

if (OperationCheck("IcerikBilgiGetir")) {
    $id = isset($_GET["id"]) ? $_GET["id"] : -1;
    if ($id == -1)
        return PrintJsonVal(["valid" => false, "err" => ["Id bulunamadı!"]]);

    $sql = "SELECT * FROM icerikler tbl WHERE tbl.id = :id LIMIT 1;";
    $result = $conn->prepare($sql);
    $kontrol = $result->execute(["id" => $id]);
    $result = $result->fetch(PDO::FETCH_ASSOC);
    PrintJsonVal($result);
}
/**/
if (OperationCheck("sil")) {
    $id = isset($_POST["id"]) ? $_POST["id"] : -1;
    if ($id == -1)
        return PrintJsonVal(["valid" => false, "err" => ["Id bulunamadı!"]]);

    $sql = "UPDATE icerikler SET kayitDurumu = 2 WHERE id = :id";
    $result = $conn->prepare($sql);
    $kontrol = $result->execute(["id" => $id]);
    $result = $result->fetch(PDO::FETCH_ASSOC);
    PrintJsonVal($result);
}

if (OperationCheck("Upload")) {
    // var_dump($_SERVER["DOCUMENT_ROOT"]);
    // exit;
    $target_dir = "/upload/";
    // $target_file = $target_dir . basename($_FILES["file"]["name"]);
    // $uploadOk = 1;
    // $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    // Check if image file is a actual image or fake image




    // Dosyayı yeni adıyla yükle
    $fileName = uniqid() . '_' . $_FILES['file']['name'];
    $uploadPath = $_SERVER["DOCUMENT_ROOT"] . $target_dir . $fileName;



    if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadPath)) {
        echo 'Dosya başarıyla yüklendi: ' . $fileName;
        echo $uploadPath;
        $insertQuery = "INSERT INTO dosyalar(filePath) VALUES (:filePath)";
        $insertStmt = $conn->prepare($insertQuery);
        $insertStmt->bindParam(':filePath', $fileName);
        $insertStmt->execute();

        header("Location: panel.php");
        exit();


    } else {
        echo 'Dosya yükleme hatası.';
    }
}


if (OperationCheck("fileList")) {
    $sql = "SELECT * FROM dosyalar tbl ";
    $result = $conn->prepare($sql);
    $kontrol = $result->execute();
    $result = $result->fetchAll(PDO::FETCH_ASSOC);
    PrintJsonVal([
        "valid" => true,
        "data" => $result,
        "err" => []
    ]);
}




