<div class="row m-0 mt-5" style="padding: 0 100px;">
<?php
for ($i = 0; $i < 12; $i++) {
    ?>

    
    <div class="col-md-3 " style="padding: 10px;">
      <div class="card" >
        <img src="..." class="card-img-top" alt="...">
        <div class="card-body">
          <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
        </div>
      </div>
    </div>
    

    <?php   
}

?>
</div>