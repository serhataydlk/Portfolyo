<?php

include_once("layout/navbar.php");

?>

<?php

include_once("layout/header.php");

?>


<div class="container d-flex justify-content-center">

    <div class="container2">

        <p style="padding:25px">

            Merhaba! Ben [Serhat Aydilek], 08 Mayıs 2001 tarihinde dünyaya gözlerimi açmış bir web tasarımcısı ve siber güvenlik tutkunu olarak karşınızdayım. Bu sayfada benimle ilgili biraz daha fazla bilgi edinebilirsiniz.

            Doğum Tarihi: 08 Mayıs 2001

            İlgilendiğim Alanlar:
            Web tasarım ve siber güvenlik benim tutkum haline geldi. Modern teknolojiyle iç içe olmayı ve dijital dünyanın karmaşıklıklarını çözmeyi seviyorum. Yaratıcı ve işlevsel web siteleri tasarlamak, güvenlik açıklarını tespit etmek ve çözmek benim için sadece bir iş değil, aynı zamanda bir sanat ve sorumluluk anlamına geliyor.

            Eğitim ve Deneyim:
            Şu ana kadar [Isparta uygulamalı bilimler üniversitesi ve 15.01.2024] eğitimimi tamamladım ve [Torbalı Belediyesi Bilgi İşlemde Web Tasarım] alanında çeşitli projelerde yer aldım. Bu süreçte edindiğim bilgi ve deneyimlerle sürekli kendimi geliştirmeye odaklanıyorum.

            Misyonum:
            Dijital dünyada siber güvenliği artırmak ve estetik açıdan etkileyici web siteleri oluşturarak insanların dijital deneyimlerini zenginleştirmek benim öncelikli misyonum. Teknolojiye olan tutkumu ve sürekli öğrenme arzumu, beni her gün daha iyiye ve daha güvenliye ulaşma yolunda ilerletiyor.

            İletişim:
            Siz de benimle iletişime geçmek, projelerinizi paylaşmak veya sadece merhaba demek isterseniz, lütfen [serhataydilek39@gmail.com] üzerinden bana ulaşın. İşbirliği yapmaktan ve yeni projelerde yer almaktan her zaman heyecan duyuyorum!

            Teşekkür ederim ve  dijital dünyada görüşmek üzere!

        </p>


    </div>

</div>

<?php

include_once("layout/footer.php");

?>