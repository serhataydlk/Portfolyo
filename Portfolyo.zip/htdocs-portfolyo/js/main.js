
    var swiper = new Swiper(".mySwiper", {
      pagination: {
        el: ".swiper-pagination",
        dynamicBullets: true,
      },
    });


    document.addEventListener("DOMContentLoaded", function () {
        // Sayfa içeriği yüklendikten sonra loader'ı gizle
        document.querySelector('.loader-wrapper').style.display = 'none';
        document.querySelector('.content').style.display = 'block';
    });
    

    $("#changeThemeBtn").on("click", function () {
      if($("body").hasClass("black-theme")){
        $("body").removeClass("black-theme");
        localStorage.setItem('siyahTema', 'false')
      }else{
        $("body").addClass("black-theme");
        localStorage.setItem('siyahTema', 'true')
      }
    })

    document.addEventListener('DOMContentLoaded',function(){
      const siyahTemaDurumu = localStorage.getItem('siyahTema');
      if(siyahTemaDurumu === 'true'){
        $("body").addClass("black-theme");
      }
    })