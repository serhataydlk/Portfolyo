
    <?php
        include_once("layout/header.php");
        include_once("layout/navbar.php");
    ?>

  

    <?php
    include_once("../htdocs/if.php");
    ?>


    <?php
    include_once("layout/footer.php");
    ?>

<br><br><br><br><br>

